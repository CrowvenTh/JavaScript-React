 var calc = document.getElementById('calc');
        var valor = prompt("Digite o valor ");  

function desconto() {
    if (valor === '') {
        alert('Digite um valor válido ');
        calc.innerHTML = "Tente novamente ";
    } else {
        if (valor >= 500) {
            calc.innerHTML = "O valor final é de R$" + (valor - valor * 0.05);
        } else {
            calc.innerHTML = "O valor final é de R$" + (valor - valor * 0.10);
        }
    }
}